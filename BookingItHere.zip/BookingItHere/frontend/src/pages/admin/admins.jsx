import React from 'react';
import './admin.css';

export default function AdminPage() {

    return (
        <div>
            <h1>Dashboard</h1>
        </div>
    );
}