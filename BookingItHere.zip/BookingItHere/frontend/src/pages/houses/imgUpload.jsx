import React from 'react';
import FilesUpload from "../../components/fileupload";

/**
 * @author João Ponte
 * @returns {JSX.Element}
 * @constructor
 */
export default function ImgUpload() {
    return (
        <div>
            <FilesUpload/>
        </div>
    );
}