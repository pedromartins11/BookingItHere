module.exports = {
    mailhog: {
        host: "mailhog",
        smtp_port: 1025
    }
}