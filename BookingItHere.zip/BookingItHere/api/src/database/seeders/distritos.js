module.exports = [
  {
    "id_distrito": "1",
    "nome": "Aveiro"
  },
  {
    "id_distrito": "2",
    "nome": "Beja"
  },
  {
    "id_distrito": "3",
    "nome": "Braga"
  },
  {
    "id_distrito": "4",
    "nome": "Bragança"
  },
  {
    "id_distrito": "5",
    "nome": "Castelo Branco"
  },
  {
    "id_distrito": "6",
    "nome": "Coimbra"
  },
  {
    "id_distrito": "7",
    "nome": "Évora"
  },
  {
    "id_distrito": "8",
    "nome": "Faro"
  },
  {
    "id_distrito": "9",
    "nome": "Guarda"
  },
  {
    "id_distrito": "10",
    "nome": "Leiria"
  },
  {
    "id_distrito": "11",
    "nome": "Lisboa"
  },
  {
    "id_distrito": "12",
    "nome": "Portalegre"
  },
  {
    "id_distrito": "13",
    "nome": "Porto"
  },
  {
    "id_distrito": "14",
    "nome": "Santarém"
  },
  {
    "id_distrito": "15",
    "nome": "Setúbal"
  },
  {
    "id_distrito": "16",
    "nome": "Viana do Castelo"
  },
  {
    "id_distrito": "17",
    "nome": "Vila Real"
  },
  {
    "id_distrito": "18",
    "nome": "Viseu"
  },
  {
    "id_distrito": "19",
    "nome": "Açores"
  },
  {
    "id_distrito": "20",
    "nome": "Madeira"
  },
  {
    "id_distrito": "21",
    "nome": "Outro"
  }
]