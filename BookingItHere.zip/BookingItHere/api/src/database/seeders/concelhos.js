module.exports = [
    {
        "id_concelho": "1",
        "id_distrito": "14",
        "nome": "Abrantes"
    },
    {
        "id_concelho": "2",
        "id_distrito": "1",
        "nome": "Águeda"
    },
    {
        "id_concelho": "3",
        "id_distrito": "9",
        "nome": "Aguiar da Beira"
    },
    {
        "id_concelho": "4",
        "id_distrito": "7",
        "nome": "Alandroal"
    },
    {
        "id_concelho": "5",
        "id_distrito": "1",
        "nome": "Albergaria-a-Velha"
    },
    {
        "id_concelho": "6",
        "id_distrito": "8",
        "nome": "Albufeira"
    },
    {
        "id_concelho": "7",
        "id_distrito": "15",
        "nome": "Alcácer do Sal"
    },
    {
        "id_concelho": "8",
        "id_distrito": "14",
        "nome": "Alcanena"
    },
    {
        "id_concelho": "9",
        "id_distrito": "10",
        "nome": "Alcobaça"
    },
    {
        "id_concelho": "10",
        "id_distrito": "15",
        "nome": "Alcochete"
    },
    {
        "id_concelho": "11",
        "id_distrito": "8",
        "nome": "Alcoutim"
    },
    {
        "id_concelho": "12",
        "id_distrito": "11",
        "nome": "Alenquer"
    },
    {
        "id_concelho": "13",
        "id_distrito": "4",
        "nome": "Alfândega da Fé"
    },
    {
        "id_concelho": "14",
        "id_distrito": "17",
        "nome": "Alijó"
    },
    {
        "id_concelho": "15",
        "id_distrito": "8",
        "nome": "Aljezur"
    },
    {
        "id_concelho": "16",
        "id_distrito": "2",
        "nome": "Aljustrel"
    },
    {
        "id_concelho": "17",
        "id_distrito": "15",
        "nome": "Almada"
    },
    {
        "id_concelho": "18",
        "id_distrito": "9",
        "nome": "Almeida"
    },
    {
        "id_concelho": "19",
        "id_distrito": "14",
        "nome": "Almeirim"
    },
    {
        "id_concelho": "20",
        "id_distrito": "2",
        "nome": "Almodôvar"
    },
    {
        "id_concelho": "21",
        "id_distrito": "14",
        "nome": "Alpiarça"
    },
    {
        "id_concelho": "22",
        "id_distrito": "12",
        "nome": "Alter do Chão"
    },
    {
        "id_concelho": "23",
        "id_distrito": "10",
        "nome": "Alvaiázere"
    },
    {
        "id_concelho": "24",
        "id_distrito": "2",
        "nome": "Alvito"
    },
    {
        "id_concelho": "25",
        "id_distrito": "11",
        "nome": "Amadora"
    },
    {
        "id_concelho": "26",
        "id_distrito": "13",
        "nome": "Amarante"
    },
    {
        "id_concelho": "27",
        "id_distrito": "3",
        "nome": "Amares"
    },
    {
        "id_concelho": "28",
        "id_distrito": "1",
        "nome": "Anadia"
    },
    {
        "id_concelho": "29",
        "id_distrito": "19",
        "nome": "Angra do Heroísmo"
    },
    {
        "id_concelho": "30",
        "id_distrito": "10",
        "nome": "Ansião"
    },
    {
        "id_concelho": "31",
        "id_distrito": "16",
        "nome": "Arcos de Valdevez"
    },
    {
        "id_concelho": "32",
        "id_distrito": "6",
        "nome": "Arganil"
    },
    {
        "id_concelho": "33",
        "id_distrito": "18",
        "nome": "Armamar"
    },
    {
        "id_concelho": "34",
        "id_distrito": "1",
        "nome": "Arouca"
    },
    {
        "id_concelho": "35",
        "id_distrito": "7",
        "nome": "Arraiolos"
    },
    {
        "id_concelho": "36",
        "id_distrito": "12",
        "nome": "Arronches"
    },
    {
        "id_concelho": "37",
        "id_distrito": "11",
        "nome": "Arruda dos Vinhos"
    },
    {
        "id_concelho": "38",
        "id_distrito": "1",
        "nome": "Aveiro"
    },
    {
        "id_concelho": "39",
        "id_distrito": "12",
        "nome": "Avis"
    },
    {
        "id_concelho": "40",
        "id_distrito": "11",
        "nome": "Azambuja"
    },
    {
        "id_concelho": "41",
        "id_distrito": "13",
        "nome": "Baião"
    },
    {
        "id_concelho": "42",
        "id_distrito": "3",
        "nome": "Barcelos"
    },
    {
        "id_concelho": "43",
        "id_distrito": "2",
        "nome": "Barrancos"
    },
    {
        "id_concelho": "44",
        "id_distrito": "15",
        "nome": "Barreiro"
    },
    {
        "id_concelho": "45",
        "id_distrito": "10",
        "nome": "Batalha"
    },
    {
        "id_concelho": "46",
        "id_distrito": "2",
        "nome": "Beja"
    },
    {
        "id_concelho": "47",
        "id_distrito": "5",
        "nome": "Belmonte"
    },
    {
        "id_concelho": "48",
        "id_distrito": "14",
        "nome": "Benavente"
    },
    {
        "id_concelho": "49",
        "id_distrito": "10",
        "nome": "Bombarral"
    },
    {
        "id_concelho": "50",
        "id_distrito": "7",
        "nome": "Borba"
    },
    {
        "id_concelho": "51",
        "id_distrito": "17",
        "nome": "Boticas"
    },
    {
        "id_concelho": "52",
        "id_distrito": "3",
        "nome": "Braga"
    },
    {
        "id_concelho": "53",
        "id_distrito": "4",
        "nome": "Bragança"
    },
    {
        "id_concelho": "54",
        "id_distrito": "3",
        "nome": "Cabeceiras de Basto"
    },
    {
        "id_concelho": "55",
        "id_distrito": "11",
        "nome": "Cadaval"
    },
    {
        "id_concelho": "56",
        "id_distrito": "10",
        "nome": "Caldas da Rainha"
    },
    {
        "id_concelho": "57",
        "id_distrito": "19",
        "nome": "Calheta (Açores)"
    },
    {
        "id_concelho": "58",
        "id_distrito": "20",
        "nome": "Calheta (Madeira)"
    },
    {
        "id_concelho": "59",
        "id_distrito": "20",
        "nome": "Câmara de Lobos"
    },
    {
        "id_concelho": "60",
        "id_distrito": "16",
        "nome": "Caminha"
    },
    {
        "id_concelho": "61",
        "id_distrito": "12",
        "nome": "Campo Maior"
    },
    {
        "id_concelho": "62",
        "id_distrito": "6",
        "nome": "Cantanhede"
    },
    {
        "id_concelho": "63",
        "id_distrito": "4",
        "nome": "Carrazeda de Ansiães"
    },
    {
        "id_concelho": "64",
        "id_distrito": "18",
        "nome": "Carregal do Sal"
    },
    {
        "id_concelho": "65",
        "id_distrito": "14",
        "nome": "Cartaxo"
    },
    {
        "id_concelho": "66",
        "id_distrito": "11",
        "nome": "Cascais"
    },
    {
        "id_concelho": "67",
        "id_distrito": "10",
        "nome": "Castanheira de Pêra"
    },
    {
        "id_concelho": "68",
        "id_distrito": "5",
        "nome": "Castelo Branco"
    },
    {
        "id_concelho": "69",
        "id_distrito": "1",
        "nome": "Castelo de Paiva"
    },
    {
        "id_concelho": "70",
        "id_distrito": "12",
        "nome": "Castelo de Vide"
    },
    {
        "id_concelho": "71",
        "id_distrito": "18",
        "nome": "Castro Daire"
    },
    {
        "id_concelho": "72",
        "id_distrito": "8",
        "nome": "Castro Marim"
    },
    {
        "id_concelho": "73",
        "id_distrito": "2",
        "nome": "Castro Verde"
    },
    {
        "id_concelho": "74",
        "id_distrito": "9",
        "nome": "Celorico da Beira"
    },
    {
        "id_concelho": "75",
        "id_distrito": "3",
        "nome": "Celorico de Basto"
    },
    {
        "id_concelho": "76",
        "id_distrito": "14",
        "nome": "Chamusca"
    },
    {
        "id_concelho": "77",
        "id_distrito": "17",
        "nome": "Chaves"
    },
    {
        "id_concelho": "78",
        "id_distrito": "18",
        "nome": "Cinfães"
    },
    {
        "id_concelho": "79",
        "id_distrito": "6",
        "nome": "Coimbra"
    },
    {
        "id_concelho": "80",
        "id_distrito": "6",
        "nome": "Condeixa-a-Nova"
    },
    {
        "id_concelho": "81",
        "id_distrito": "14",
        "nome": "Constância"
    },
    {
        "id_concelho": "82",
        "id_distrito": "14",
        "nome": "Coruche"
    },
    {
        "id_concelho": "83",
        "id_distrito": "19",
        "nome": "Corvo"
    },
    {
        "id_concelho": "84",
        "id_distrito": "5",
        "nome": "Covilhã"
    },
    {
        "id_concelho": "85",
        "id_distrito": "12",
        "nome": "Crato"
    },
    {
        "id_concelho": "86",
        "id_distrito": "2",
        "nome": "Cuba"
    },
    {
        "id_concelho": "87",
        "id_distrito": "12",
        "nome": "Elvas"
    },
    {
        "id_concelho": "88",
        "id_distrito": "14",
        "nome": "Entroncamento"
    },
    {
        "id_concelho": "89",
        "id_distrito": "1",
        "nome": "Espinho"
    },
    {
        "id_concelho": "90",
        "id_distrito": "3",
        "nome": "Esposende"
    },
    {
        "id_concelho": "91",
        "id_distrito": "1",
        "nome": "Estarreja"
    },
    {
        "id_concelho": "92",
        "id_distrito": "7",
        "nome": "Estremoz"
    },
    {
        "id_concelho": "93",
        "id_distrito": "7",
        "nome": "Évora"
    },
    {
        "id_concelho": "94",
        "id_distrito": "3",
        "nome": "Fafe"
    },
    {
        "id_concelho": "95",
        "id_distrito": "8",
        "nome": "Faro"
    },
    {
        "id_concelho": "96",
        "id_distrito": "13",
        "nome": "Felgueiras"
    },
    {
        "id_concelho": "97",
        "id_distrito": "2",
        "nome": "Ferreira do Alentejo"
    },
    {
        "id_concelho": "98",
        "id_distrito": "14",
        "nome": "Ferreira do Zêzere"
    },
    {
        "id_concelho": "99",
        "id_distrito": "6",
        "nome": "Figueira da Foz"
    },
    {
        "id_concelho": "100",
        "id_distrito": "9",
        "nome": "Figueira de Castelo Rodrigo"
    },
    {
        "id_concelho": "101",
        "id_distrito": "10",
        "nome": "Figueiró dos Vinhos"
    },
    {
        "id_concelho": "102",
        "id_distrito": "9",
        "nome": "Fornos de Algodres"
    },
    {
        "id_concelho": "103",
        "id_distrito": "4",
        "nome": "Freixo de Espada à Cinta"
    },
    {
        "id_concelho": "104",
        "id_distrito": "12",
        "nome": "Fronteira"
    },
    {
        "id_concelho": "105",
        "id_distrito": "20",
        "nome": "Funchal"
    },
    {
        "id_concelho": "106",
        "id_distrito": "5",
        "nome": "Fundão"
    },
    {
        "id_concelho": "107",
        "id_distrito": "12",
        "nome": "Gavião"
    },
    {
        "id_concelho": "108",
        "id_distrito": "6",
        "nome": "Góis"
    },
    {
        "id_concelho": "109",
        "id_distrito": "14",
        "nome": "Golegã"
    },
    {
        "id_concelho": "110",
        "id_distrito": "13",
        "nome": "Gondomar"
    },
    {
        "id_concelho": "111",
        "id_distrito": "9",
        "nome": "Gouveia"
    },
    {
        "id_concelho": "112",
        "id_distrito": "15",
        "nome": "Grândola"
    },
    {
        "id_concelho": "113",
        "id_distrito": "9",
        "nome": "Guarda"
    },
    {
        "id_concelho": "114",
        "id_distrito": "3",
        "nome": "Guimarães"
    },
    {
        "id_concelho": "115",
        "id_distrito": "19",
        "nome": "Horta"
    },
    {
        "id_concelho": "116",
        "id_distrito": "5",
        "nome": "Idanha-a-Nova"
    },
    {
        "id_concelho": "117",
        "id_distrito": "1",
        "nome": "Ílhavo"
    },
    {
        "id_concelho": "118",
        "id_distrito": "19",
        "nome": "Lagoa (Açores)"
    },
    {
        "id_concelho": "119",
        "id_distrito": "8",
        "nome": "Lagoa (Algarve)"
    },
    {
        "id_concelho": "120",
        "id_distrito": "8",
        "nome": "Lagos"
    },
    {
        "id_concelho": "121",
        "id_distrito": "19",
        "nome": "Lajes das Flores"
    },
    {
        "id_concelho": "122",
        "id_distrito": "19",
        "nome": "Lajes do Pico"
    },
    {
        "id_concelho": "123",
        "id_distrito": "18",
        "nome": "Lamego"
    },
    {
        "id_concelho": "124",
        "id_distrito": "10",
        "nome": "Leiria"
    },
    {
        "id_concelho": "125",
        "id_distrito": "11",
        "nome": "Lisboa"
    },
    {
        "id_concelho": "126",
        "id_distrito": "8",
        "nome": "Loulé"
    },
    {
        "id_concelho": "127",
        "id_distrito": "11",
        "nome": "Loures"
    },
    {
        "id_concelho": "128",
        "id_distrito": "11",
        "nome": "Lourinhã"
    },
    {
        "id_concelho": "129",
        "id_distrito": "6",
        "nome": "Lousã"
    },
    {
        "id_concelho": "130",
        "id_distrito": "13",
        "nome": "Lousada"
    },
    {
        "id_concelho": "131",
        "id_distrito": "14",
        "nome": "Mação"
    },
    {
        "id_concelho": "132",
        "id_distrito": "4",
        "nome": "Macedo de Cavaleiros"
    },
    {
        "id_concelho": "133",
        "id_distrito": "20",
        "nome": "Machico"
    },
    {
        "id_concelho": "134",
        "id_distrito": "19",
        "nome": "Madalena"
    },
    {
        "id_concelho": "135",
        "id_distrito": "11",
        "nome": "Mafra"
    },
    {
        "id_concelho": "136",
        "id_distrito": "13",
        "nome": "Maia"
    },
    {
        "id_concelho": "137",
        "id_distrito": "18",
        "nome": "Mangualde"
    },
    {
        "id_concelho": "138",
        "id_distrito": "9",
        "nome": "Manteigas"
    },
    {
        "id_concelho": "139",
        "id_distrito": "13",
        "nome": "Marco de Canaveses"
    },
    {
        "id_concelho": "140",
        "id_distrito": "10",
        "nome": "Marinha Grande"
    },
    {
        "id_concelho": "141",
        "id_distrito": "12",
        "nome": "Marvão"
    },
    {
        "id_concelho": "142",
        "id_distrito": "13",
        "nome": "Matosinhos"
    },
    {
        "id_concelho": "143",
        "id_distrito": "1",
        "nome": "Mealhada"
    },
    {
        "id_concelho": "144",
        "id_distrito": "9",
        "nome": "Mêda"
    },
    {
        "id_concelho": "145",
        "id_distrito": "16",
        "nome": "Melgaço"
    },
    {
        "id_concelho": "146",
        "id_distrito": "2",
        "nome": "Mértola"
    },
    {
        "id_concelho": "147",
        "id_distrito": "17",
        "nome": "Mesão Frio"
    },
    {
        "id_concelho": "148",
        "id_distrito": "6",
        "nome": "Mira"
    },
    {
        "id_concelho": "149",
        "id_distrito": "6",
        "nome": "Miranda do Corvo"
    },
    {
        "id_concelho": "150",
        "id_distrito": "4",
        "nome": "Miranda do Douro"
    },
    {
        "id_concelho": "151",
        "id_distrito": "4",
        "nome": "Mirandela"
    },
    {
        "id_concelho": "152",
        "id_distrito": "4",
        "nome": "Mogadouro"
    },
    {
        "id_concelho": "153",
        "id_distrito": "18",
        "nome": "Moimenta da Beira"
    },
    {
        "id_concelho": "154",
        "id_distrito": "15",
        "nome": "Moita"
    },
    {
        "id_concelho": "155",
        "id_distrito": "16",
        "nome": "Monção"
    },
    {
        "id_concelho": "156",
        "id_distrito": "8",
        "nome": "Monchique"
    },
    {
        "id_concelho": "157",
        "id_distrito": "17",
        "nome": "Mondim de Basto"
    },
    {
        "id_concelho": "158",
        "id_distrito": "12",
        "nome": "Monforte"
    },
    {
        "id_concelho": "159",
        "id_distrito": "17",
        "nome": "Montalegre"
    },
    {
        "id_concelho": "160",
        "id_distrito": "7",
        "nome": "Montemor-o-Novo"
    },
    {
        "id_concelho": "161",
        "id_distrito": "6",
        "nome": "Montemor-o-Velho"
    },
    {
        "id_concelho": "162",
        "id_distrito": "15",
        "nome": "Montijo"
    },
    {
        "id_concelho": "163",
        "id_distrito": "7",
        "nome": "Mora"
    },
    {
        "id_concelho": "164",
        "id_distrito": "18",
        "nome": "Mortágua"
    },
    {
        "id_concelho": "165",
        "id_distrito": "2",
        "nome": "Moura"
    },
    {
        "id_concelho": "166",
        "id_distrito": "7",
        "nome": "Mourão"
    },
    {
        "id_concelho": "167",
        "id_distrito": "17",
        "nome": "Murça"
    },
    {
        "id_concelho": "168",
        "id_distrito": "1",
        "nome": "Murtosa"
    },
    {
        "id_concelho": "169",
        "id_distrito": "10",
        "nome": "Nazaré"
    },
    {
        "id_concelho": "170",
        "id_distrito": "18",
        "nome": "Nelas"
    },
    {
        "id_concelho": "171",
        "id_distrito": "12",
        "nome": "Nisa"
    },
    {
        "id_concelho": "172",
        "id_distrito": "19",
        "nome": "Nordeste"
    },
    {
        "id_concelho": "173",
        "id_distrito": "10",
        "nome": "Óbidos"
    },
    {
        "id_concelho": "174",
        "id_distrito": "2",
        "nome": "Odemira"
    },
    {
        "id_concelho": "175",
        "id_distrito": "11",
        "nome": "Odivelas"
    },
    {
        "id_concelho": "176",
        "id_distrito": "11",
        "nome": "Oeiras"
    },
    {
        "id_concelho": "177",
        "id_distrito": "5",
        "nome": "Oleiros"
    },
    {
        "id_concelho": "178",
        "id_distrito": "8",
        "nome": "Olhão"
    },
    {
        "id_concelho": "179",
        "id_distrito": "1",
        "nome": "Oliveira de Azeméis"
    },
    {
        "id_concelho": "180",
        "id_distrito": "18",
        "nome": "Oliveira de Frades"
    },
    {
        "id_concelho": "181",
        "id_distrito": "1",
        "nome": "Oliveira do Bairro"
    },
    {
        "id_concelho": "182",
        "id_distrito": "6",
        "nome": "Oliveira do Hospital"
    },
    {
        "id_concelho": "183",
        "id_distrito": "14",
        "nome": "Ourém"
    },
    {
        "id_concelho": "184",
        "id_distrito": "2",
        "nome": "Ourique"
    },
    {
        "id_concelho": "185",
        "id_distrito": "1",
        "nome": "Ovar"
    },
    {
        "id_concelho": "186",
        "id_distrito": "13",
        "nome": "Paços de Ferreira"
    },
    {
        "id_concelho": "187",
        "id_distrito": "15",
        "nome": "Palmela"
    },
    {
        "id_concelho": "188",
        "id_distrito": "6",
        "nome": "Pampilhosa da Serra"
    },
    {
        "id_concelho": "189",
        "id_distrito": "13",
        "nome": "Paredes"
    },
    {
        "id_concelho": "190",
        "id_distrito": "16",
        "nome": "Paredes de Coura"
    },
    {
        "id_concelho": "191",
        "id_distrito": "10",
        "nome": "Pedrógão Grande"
    },
    {
        "id_concelho": "192",
        "id_distrito": "6",
        "nome": "Penacova"
    },
    {
        "id_concelho": "193",
        "id_distrito": "13",
        "nome": "Penafiel"
    },
    {
        "id_concelho": "194",
        "id_distrito": "18",
        "nome": "Penalva do Castelo"
    },
    {
        "id_concelho": "195",
        "id_distrito": "5",
        "nome": "Penamacor"
    },
    {
        "id_concelho": "196",
        "id_distrito": "18",
        "nome": "Penedono"
    },
    {
        "id_concelho": "197",
        "id_distrito": "6",
        "nome": "Penela"
    },
    {
        "id_concelho": "198",
        "id_distrito": "10",
        "nome": "Peniche"
    },
    {
        "id_concelho": "199",
        "id_distrito": "17",
        "nome": "Peso da Régua"
    },
    {
        "id_concelho": "200",
        "id_distrito": "9",
        "nome": "Pinhel"
    },
    {
        "id_concelho": "201",
        "id_distrito": "10",
        "nome": "Pombal"
    },
    {
        "id_concelho": "202",
        "id_distrito": "19",
        "nome": "Ponta Delgada"
    },
    {
        "id_concelho": "203",
        "id_distrito": "20",
        "nome": "Ponta do Sol"
    },
    {
        "id_concelho": "204",
        "id_distrito": "16",
        "nome": "Ponte da Barca"
    },
    {
        "id_concelho": "205",
        "id_distrito": "16",
        "nome": "Ponte de Lima"
    },
    {
        "id_concelho": "206",
        "id_distrito": "12",
        "nome": "Ponte de Sor"
    },
    {
        "id_concelho": "207",
        "id_distrito": "12",
        "nome": "Portalegre"
    },
    {
        "id_concelho": "208",
        "id_distrito": "7",
        "nome": "Portel"
    },
    {
        "id_concelho": "209",
        "id_distrito": "8",
        "nome": "Portimão"
    },
    {
        "id_concelho": "210",
        "id_distrito": "13",
        "nome": "Porto"
    },
    {
        "id_concelho": "211",
        "id_distrito": "10",
        "nome": "Porto de Mós"
    },
    {
        "id_concelho": "212",
        "id_distrito": "20",
        "nome": "Porto Moniz"
    },
    {
        "id_concelho": "213",
        "id_distrito": "20",
        "nome": "Porto Santo"
    },
    {
        "id_concelho": "214",
        "id_distrito": "3",
        "nome": "Póvoa de Lanhoso"
    },
    {
        "id_concelho": "215",
        "id_distrito": "13",
        "nome": "Póvoa de Varzim"
    },
    {
        "id_concelho": "216",
        "id_distrito": "19",
        "nome": "Povoação"
    },
    {
        "id_concelho": "217",
        "id_distrito": "19",
        "nome": "Praia da Vitória"
    },
    {
        "id_concelho": "218",
        "id_distrito": "5",
        "nome": "Proença-a-Nova"
    },
    {
        "id_concelho": "219",
        "id_distrito": "7",
        "nome": "Redondo"
    },
    {
        "id_concelho": "220",
        "id_distrito": "7",
        "nome": "Reguengos de Monsaraz"
    },
    {
        "id_concelho": "221",
        "id_distrito": "18",
        "nome": "Resende"
    },
    {
        "id_concelho": "222",
        "id_distrito": "20",
        "nome": "Ribeira Brava"
    },
    {
        "id_concelho": "223",
        "id_distrito": "17",
        "nome": "Ribeira de Pena"
    },
    {
        "id_concelho": "224",
        "id_distrito": "19",
        "nome": "Ribeira Grande"
    },
    {
        "id_concelho": "225",
        "id_distrito": "14",
        "nome": "Rio Maior"
    },
    {
        "id_concelho": "226",
        "id_distrito": "17",
        "nome": "Sabrosa"
    },
    {
        "id_concelho": "227",
        "id_distrito": "9",
        "nome": "Sabugal"
    },
    {
        "id_concelho": "228",
        "id_distrito": "14",
        "nome": "Salvaterra de Magos"
    },
    {
        "id_concelho": "229",
        "id_distrito": "18",
        "nome": "Santa Comba Dão"
    },
    {
        "id_concelho": "230",
        "id_distrito": "20",
        "nome": "Santa Cruz"
    },
    {
        "id_concelho": "231",
        "id_distrito": "19",
        "nome": "Santa Cruz da Graciosa"
    },
    {
        "id_concelho": "232",
        "id_distrito": "19",
        "nome": "Santa Cruz das Flores"
    },
    {
        "id_concelho": "233",
        "id_distrito": "1",
        "nome": "Santa Maria da Feira"
    },
    {
        "id_concelho": "234",
        "id_distrito": "17",
        "nome": "Santa Marta de Penaguião"
    },
    {
        "id_concelho": "235",
        "id_distrito": "20",
        "nome": "Santana"
    },
    {
        "id_concelho": "236",
        "id_distrito": "14",
        "nome": "Santarém"
    },
    {
        "id_concelho": "237",
        "id_distrito": "15",
        "nome": "Santiago do Cacém"
    },
    {
        "id_concelho": "238",
        "id_distrito": "13",
        "nome": "Santo Tirso"
    },
    {
        "id_concelho": "239",
        "id_distrito": "8",
        "nome": "São Brás de Alportel"
    },
    {
        "id_concelho": "240",
        "id_distrito": "1",
        "nome": "São João da Madeira"
    },
    {
        "id_concelho": "241",
        "id_distrito": "18",
        "nome": "São João da Pesqueira"
    },
    {
        "id_concelho": "242",
        "id_distrito": "18",
        "nome": "São Pedro do Sul"
    },
    {
        "id_concelho": "243",
        "id_distrito": "19",
        "nome": "São Roque do Pico"
    },
    {
        "id_concelho": "244",
        "id_distrito": "20",
        "nome": "São Vicente"
    },
    {
        "id_concelho": "245",
        "id_distrito": "14",
        "nome": "Sardoal"
    },
    {
        "id_concelho": "246",
        "id_distrito": "18",
        "nome": "Sátão"
    },
    {
        "id_concelho": "247",
        "id_distrito": "9",
        "nome": "Seia"
    },
    {
        "id_concelho": "248",
        "id_distrito": "15",
        "nome": "Seixal"
    },
    {
        "id_concelho": "249",
        "id_distrito": "18",
        "nome": "Sernancelhe"
    },
    {
        "id_concelho": "250",
        "id_distrito": "2",
        "nome": "Serpa"
    },
    {
        "id_concelho": "251",
        "id_distrito": "5",
        "nome": "Sertã"
    },
    {
        "id_concelho": "252",
        "id_distrito": "15",
        "nome": "Sesimbra"
    },
    {
        "id_concelho": "253",
        "id_distrito": "15",
        "nome": "Setúbal"
    },
    {
        "id_concelho": "254",
        "id_distrito": "1",
        "nome": "Sever do Vouga"
    },
    {
        "id_concelho": "255",
        "id_distrito": "8",
        "nome": "Silves"
    },
    {
        "id_concelho": "256",
        "id_distrito": "15",
        "nome": "Sines"
    },
    {
        "id_concelho": "257",
        "id_distrito": "11",
        "nome": "Sintra"
    },
    {
        "id_concelho": "258",
        "id_distrito": "11",
        "nome": "Sobral de Monte Agraço"
    },
    {
        "id_concelho": "259",
        "id_distrito": "6",
        "nome": "Soure"
    },
    {
        "id_concelho": "260",
        "id_distrito": "12",
        "nome": "Sousel"
    },
    {
        "id_concelho": "261",
        "id_distrito": "6",
        "nome": "Tábua"
    },
    {
        "id_concelho": "262",
        "id_distrito": "18",
        "nome": "Tabuaço"
    },
    {
        "id_concelho": "263",
        "id_distrito": "18",
        "nome": "Tarouca"
    },
    {
        "id_concelho": "264",
        "id_distrito": "8",
        "nome": "Tavira"
    },
    {
        "id_concelho": "265",
        "id_distrito": "3",
        "nome": "Terras de Bouro"
    },
    {
        "id_concelho": "266",
        "id_distrito": "14",
        "nome": "Tomar"
    },
    {
        "id_concelho": "267",
        "id_distrito": "18",
        "nome": "Tondela"
    },
    {
        "id_concelho": "268",
        "id_distrito": "4",
        "nome": "Torre de Moncorvo"
    },
    {
        "id_concelho": "269",
        "id_distrito": "14",
        "nome": "Torres Novas"
    },
    {
        "id_concelho": "270",
        "id_distrito": "11",
        "nome": "Torres Vedras"
    },
    {
        "id_concelho": "271",
        "id_distrito": "9",
        "nome": "Trancoso"
    },
    {
        "id_concelho": "272",
        "id_distrito": "13",
        "nome": "Trofa"
    },
    {
        "id_concelho": "273",
        "id_distrito": "1",
        "nome": "Vagos"
    },
    {
        "id_concelho": "274",
        "id_distrito": "1",
        "nome": "Vale de Cambra"
    },
    {
        "id_concelho": "275",
        "id_distrito": "16",
        "nome": "Valença"
    },
    {
        "id_concelho": "276",
        "id_distrito": "13",
        "nome": "Valongo"
    },
    {
        "id_concelho": "277",
        "id_distrito": "17",
        "nome": "Valpaços"
    },
    {
        "id_concelho": "278",
        "id_distrito": "19",
        "nome": "Velas"
    },
    {
        "id_concelho": "279",
        "id_distrito": "7",
        "nome": "Vendas Novas"
    },
    {
        "id_concelho": "280",
        "id_distrito": "7",
        "nome": "Viana do Alentejo"
    },
    {
        "id_concelho": "281",
        "id_distrito": "16",
        "nome": "Viana do Castelo"
    },
    {
        "id_concelho": "282",
        "id_distrito": "2",
        "nome": "Vidigueira"
    },
    {
        "id_concelho": "283",
        "id_distrito": "3",
        "nome": "Vieira do Minho"
    },
    {
        "id_concelho": "284",
        "id_distrito": "5",
        "nome": "Vila de Rei"
    },
    {
        "id_concelho": "285",
        "id_distrito": "8",
        "nome": "Vila do Bispo"
    },
    {
        "id_concelho": "286",
        "id_distrito": "13",
        "nome": "Vila do Conde"
    },
    {
        "id_concelho": "287",
        "id_distrito": "19",
        "nome": "Vila do Porto"
    },
    {
        "id_concelho": "288",
        "id_distrito": "4",
        "nome": "Vila Flor"
    },
    {
        "id_concelho": "289",
        "id_distrito": "11",
        "nome": "Vila Franca de Xira"
    },
    {
        "id_concelho": "290",
        "id_distrito": "19",
        "nome": "Vila Franca do Campo"
    },
    {
        "id_concelho": "291",
        "id_distrito": "14",
        "nome": "Vila Nova da Barquinha"
    },
    {
        "id_concelho": "292",
        "id_distrito": "16",
        "nome": "Vila Nova de Cerveira"
    },
    {
        "id_concelho": "293",
        "id_distrito": "3",
        "nome": "Vila Nova de Famalicão"
    },
    {
        "id_concelho": "294",
        "id_distrito": "9",
        "nome": "Vila Nova de Foz Côa"
    },
    {
        "id_concelho": "295",
        "id_distrito": "13",
        "nome": "Vila Nova de Gaia"
    },
    {
        "id_concelho": "296",
        "id_distrito": "18",
        "nome": "Vila Nova de Paiva"
    },
    {
        "id_concelho": "297",
        "id_distrito": "6",
        "nome": "Vila Nova de Poiares"
    },
    {
        "id_concelho": "298",
        "id_distrito": "17",
        "nome": "Vila Pouca de Aguiar"
    },
    {
        "id_concelho": "299",
        "id_distrito": "17",
        "nome": "Vila Real"
    },
    {
        "id_concelho": "300",
        "id_distrito": "8",
        "nome": "Vila Real de Santo António"
    },
    {
        "id_concelho": "301",
        "id_distrito": "5",
        "nome": "Vila Velha de Ródão"
    },
    {
        "id_concelho": "302",
        "id_distrito": "3",
        "nome": "Vila Verde"
    },
    {
        "id_concelho": "303",
        "id_distrito": "7",
        "nome": "Vila Viçosa"
    },
    {
        "id_concelho": "304",
        "id_distrito": "4",
        "nome": "Vimioso"
    },
    {
        "id_concelho": "305",
        "id_distrito": "4",
        "nome": "Vinhais"
    },
    {
        "id_concelho": "306",
        "id_distrito": "18",
        "nome": "Viseu"
    },
    {
        "id_concelho": "307",
        "id_distrito": "3",
        "nome": "Vizela"
    },
    {
        "id_concelho": "308",
        "id_distrito": "18",
        "nome": "Vouzela"
    },
    {
        "id_concelho": "309",
        "id_distrito": "21",
        "nome": "Não indicado"
    },
    {
        "id_concelho": "310",
        "id_distrito": "21",
        "nome": "nao indicado"
    }
]